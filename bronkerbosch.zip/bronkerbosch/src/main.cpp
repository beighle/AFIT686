/*
 * main.cpp
 *
 *  Created on: 18-jun-2015
 *      Author: M. El-Kebir
 */

#include "utils.h"
#include "bronkerbosch.h"
#include <fstream>
#include <chrono>

using namespace bk;
using namespace std;
using namespace std::chrono;

int main(int argc, char** argv)
{
  if (argc != 2)
  {
    std::cerr << "Usage: " << argv[0]
              << " <EDGE_LIST>" << std::endl;
    return 1;
  }
  
  string sfile = "data/p800_o.txt";//argv[1]);
  std::ifstream inFile(sfile);
  if (!inFile.good())
  {
    std::cerr << "Unable to open '" << sfile
              << "' for reading" << std::endl;
    return 1;
  }
  
  Graph g;
  StringNodeMap nodeToLabel(g);
  StringToNodeMap labelToNode;
  if (!readGraph(inFile, g, nodeToLabel, labelToNode))
  {
    return 1;
  }
  
  for (int ix =0;ix<3;ix++) {

	  auto start = high_resolution_clock::now();
	  BronKerbosch bkAlg(g);
	  if (ix==0)
		  bkAlg.run(BronKerbosch::BK_CLASSIC);
	  else if (ix==1)
		  bkAlg.run(BronKerbosch::BK_PIVOT);
	  else if (ix==2)
		  bkAlg.run(BronKerbosch::BK_PIVOT_DEGENERACY);

	  int max = 0;
	  const std::vector<BronKerbosch::NodeVector>& cliques = bkAlg.getMaxCliques();
	  for (size_t i = 0; i < cliques.size(); ++i)
	  {
	    const BronKerbosch::NodeVector& C = cliques[i];
	    max = C.size() > max ? C.size() : max;
	    //for (size_t j = 0; j < C.size(); ++j)
	      //std::cout << nodeToLabel[C[j]] << " ";
	    //std::cout << std::endl;
	  }
	  auto stop = high_resolution_clock::now();
	  auto duration = duration_cast<milliseconds>(stop - start);
	  cout << "time = " << duration.count() << endl;
	  cout << "cliques = " << cliques.size() << ", max = " << max << endl;;


  }
  
  return 0;
}
